package com.example.car_price_predictor;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import com.chaquo.python.PyObject
import com.chaquo.python.Python

public class MainActivity extends AppCompatActivity {
    EditText  name,year,kilometers_Driven,mileage,power,seats;
    Spinner location,fuel_Type,transmission,owner_Type;
    String name1, year1,kilo,mileage1,power1,seats1,location1,fuel1,tranmission1,owner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().hide();

        name =findViewById(R.id.name);
        location=findViewById(R.id.location);
        year=findViewById(R.id.year);
        kilometers_Driven=findViewById(R.id.kilo);
        fuel_Type=findViewById(R.id.fuel);
        transmission=findViewById(R.id.transmission);
        owner_Type=findViewById(R.id.owner);
        mileage=findViewById(R.id.mileage);
        power=findViewById(R.id.power);
        seats=findViewById(R.id.seats);

        name1=name.getText().toString();
        year1=year.getText().toString();
        kilo=kilometers_Driven.getText().toString();
        mileage1=mileage.getText().toString();
        power1=power.getText().toString();
        seats1=seats.getText().toString();
        ArrayAdapter<CharSequence>adapter=ArrayAdapter.createFromResource(this,R.array.fuel_type,android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fuel_Type.setAdapter(adapter);
        fuel_Type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                fuel1=adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        ArrayAdapter<CharSequence>adapter1=ArrayAdapter.createFromResource(this,R.array.location,android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        location.setAdapter(adapter1);
        location.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                location1=adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        ArrayAdapter<CharSequence>adapter2=ArrayAdapter.createFromResource(this,R.array.owner_type,android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        owner_Type.setAdapter(adapter2);
        owner_Type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                owner=adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        ArrayAdapter<CharSequence>adapter3=ArrayAdapter.createFromResource(this,R.array.transmission,android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        transmission.setAdapter(adapter3);
        transmission.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                tranmission1=adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        if (! Python.isStarted()) {
            Python.start(new AndroidPlatform(getApplicationContext()));
        }
        //Python.start(new AndroidPlatform(getApplicationContext()));
        val py: Python = Python.getInstance()
    }

}
